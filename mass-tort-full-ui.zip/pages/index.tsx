
import React from 'react';
import Link from 'next/link';

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-50 text-gray-900">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-6 py-6 flex justify-between items-center">
          <h1 className="text-2xl font-bold">MassTortTracker</h1>
          <nav className="space-x-6 text-indigo-600">
            <Link href="/cases">Cases</Link>
            <Link href="/intake">Check Eligibility</Link>
            <Link href="/learn">Learn</Link>
          </nav>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-12">
        <section className="mb-12 text-center">
          <h2 className="text-4xl font-bold mb-4">Information for People Injured by Dangerous Drugs & Products</h2>
          <p className="text-gray-600 text-lg max-w-3xl mx-auto">
            Clear, easy-to-understand updates on major mass tort lawsuits — including injuries reported,
            who may be affected, and what steps you can take if you believe you were harmed.
          </p>
          <div className="mt-6">
            <Link href="/intake" className="px-6 py-3 bg-indigo-600 text-white rounded-lg shadow hover:bg-indigo-700">
              Check Your Eligibility
            </Link>
          </div>
        </section>

        <section className="mb-12">
          <h3 className="text-2xl font-semibold mb-4">Top Mass Tort Cases Affecting Consumers</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {['talc','hernia_mesh','afff','zantac','paraquat','hair_relaxer'].map(id => (
              <Link key={id} href={`/cases/${id}`} className="block bg-white p-6 rounded-lg shadow hover:shadow-md">
                <h4 className="text-xl font-bold capitalize">{id.replace('_',' ')}</h4>
                <p className="text-gray-600 text-sm mt-2">Learn about recent filings, injuries reported, and litigation status.</p>
              </Link>
            ))}
          </div>
        </section>

        <section className="bg-white p-8 rounded-lg shadow mb-12">
          <h3 className="text-2xl font-semibold mb-4">Latest Consumer Safety & Litigation Updates</h3>
          <ul className="list-disc pl-6 text-gray-700 space-y-2">
            <li>J&J talc bankruptcy appeal rejected — litigation continues.</li>
            <li>AFFF PFAS contamination litigation expands with new municipal filings.</li>
            <li>Zantac global settlement programs progressing across jurisdictions.</li>
          </ul>
        </section>

        <section className="text-center">
          <h3 className="text-2xl font-semibold mb-4">See If Your Experience Fits an Active Tort Investigation</h3>
          <p className="text-gray-600 max-w-2xl mx-auto mb-6">
            If you or a loved one suffered an injury related to a medical device, medication,
            or chemical exposure, a short questionnaire can help you understand whether your symptoms
            align with an active mass tort case.
          </p>
          <Link href="/intake" className="px-6 py-3 bg-indigo-600 text-white rounded-lg shadow hover:bg-indigo-700">
            Start the 60-Second Screener
          </Link>
        </section>
      </main>

      <footer className="bg-gray-800 text-white py-6 mt-12">
        <div className="max-w-7xl mx-auto px-6 text-center text-sm">
          <p>This site provides informational updates and is not legal advice.</p>
        </div>
      </footer>
    </div>
  );
}
