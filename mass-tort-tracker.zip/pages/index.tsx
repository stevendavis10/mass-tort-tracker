// Home placeholder
export default function Home(){return <div>Mass Tort Tracker</div>}